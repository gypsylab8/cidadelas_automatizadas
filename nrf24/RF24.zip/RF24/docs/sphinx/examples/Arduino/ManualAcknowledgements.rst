ManualAcknowledgements.ino
==========================

.. literalinclude:: ../../../../examples/ManualAcknowledgements/ManualAcknowledgements.ino
    :lines: 7-
    :linenos:
    :lineno-match:
